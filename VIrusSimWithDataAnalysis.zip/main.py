import pygame,sys,random
from pygame.locals import *
from virus import Virus
from doctor import Doctor
import matplotlib.pyplot as plt

pygame.init()
screen_info = pygame.display.Info()
width,height = size = screen_info.current_w,screen_info.current_h
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
pygame.font.init()
font = pygame.font.SysFont("Helvetica",70)


WHITE = (255,255,255)
BLUE = (0,0,255)
RED = (255,0,0)
GREEN = (0,255,0)

doc_num = 20
bac_num = 5
split_time = 500

bacteria = pygame.sprite.Group()
doctors = pygame.sprite.Group()

done = False



def init():
    global split_time,bac_num,doc_num

    bacteria.empty()
    doctors.empty()
    for i in range(bac_num):
        new_virus = Virus((random.randint(50,width-50),random.randint(50,height-50)),split_time)
        bacteria.add(new_virus)

    for i in range(doc_num):
        new_doctor = Doctor((random.randint(50,width-50),random.randint(50,height-50)))
        doctors.add(new_doctor)

def process_events():
    global display,screen,done
    for event in pygame.event.get():
        if event.type == QUIT:
            done = True
        if event.type == KEYDOWN:
            if event.key == K_f:
                screen = pygame.display.set_mode(size,FULLSCREEN)
            if event.key == K_d:
                screen = pygame.display.set_mode(size)



def main():
    global done
    global split_time,bac_num,doc_num
    init()
    while not done:
        clock.tick(60)
        process_events()

        text = None
        text_rect = None
        if len(bacteria) >= split_time*bac_num:
            text = font.render("You were overrun",False,RED)
            text_rect = text.get_rect()
        elif len(bacteria) == 0:
            text = font.render("Outbreak controlled", False, RED)
            text_rect = text.get_rect()
        else:
            text = font.render("Bacteria: {}".format(len(bacteria)), False, RED)
            text_rect = text.get_rect()
            bacteria.update()
            doctors.update()
            pygame.sprite.groupcollide(bacteria,doctors,True,False)


        screen.fill(WHITE)
        bacteria.draw(screen)
        doctors.draw(screen)
        screen.blit(text,text_rect)
        pygame.display.flip()


    pygame.quit()



# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/

